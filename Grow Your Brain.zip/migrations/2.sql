
ALTER TABLE user_stats RENAME COLUMN logic_puzzles_solved TO science_puzzles_solved;
ALTER TABLE user_stats RENAME COLUMN word_puzzles_solved TO puzzle_puzzles_solved;
