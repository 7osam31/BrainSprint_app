
DROP INDEX idx_user_stats_user_id;
DROP INDEX idx_puzzle_results_user_id;
DROP INDEX idx_puzzle_results_game_session_id;
DROP INDEX idx_game_sessions_user_id;
DROP TABLE user_stats;
DROP TABLE puzzle_results;
DROP TABLE game_sessions;
