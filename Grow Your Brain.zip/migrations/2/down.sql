
ALTER TABLE user_stats RENAME COLUMN puzzle_puzzles_solved TO word_puzzles_solved;
ALTER TABLE user_stats RENAME COLUMN science_puzzles_solved TO logic_puzzles_solved;
